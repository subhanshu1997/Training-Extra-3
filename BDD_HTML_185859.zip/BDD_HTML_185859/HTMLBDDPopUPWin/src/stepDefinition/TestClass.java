package stepDefinition;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {

	@Given("^User will click on button$")
	public void user_will_click_on_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("User will click on button");
	}

	@When("^User will Open Window button$")
	public void user_will_Open_Window_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("User will Open Window button");
	}

	@Then("^Open Google Page$")
	public void open_Google_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Open Google Page");
	}

}