package stepDefinition;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestClassDriver {
	
	public static void main(String[] args) {
		
		String exepath="D:\\softwares\\chromedriver_win32\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exepath);
		WebDriver driver=new ChromeDriver();
		driver.get("file:///D:/html/TestHTMLUnit.html");
	}

}
