import { PipeTransform, Pipe } from "@angular/core";

@Pipe({
    name:'pipe'
})

export class mypipe implements PipeTransform{
    transform(items: any[], status1: string, value:string){
        if(value=="")
            return items
        else if(status1 == "id"){
            console.log("hello")
            return items.filter(e=>e.id.toString().toLowerCase().includes(value.toString().toLowerCase()))
        }
        else if(status1=="year"){
            return items.filter(e=>e.year.toString().toLowerCase().includes(value.toString().toLowerCase()))
        }
        else if(status1=="title"){
            return items.filter(e=>e.title.toString().toLowerCase().includes(value.toString().toLowerCase()))
        }
        else{
            return items.filter(e=>e.author.toString().toLowerCase().includes(value))
        }
    }

}