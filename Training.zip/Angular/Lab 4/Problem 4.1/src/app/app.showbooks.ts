import { Component, Input, EventEmitter, Output, SimpleChanges } from "@angular/core";
import { BookService } from "./app.bookservice";

@Component({
    selector:'show-Books',
    templateUrl:'app.showBooks.html',
    styleUrls:['app.showBooks.css']    
})
export class ShowBooks{
    booksAll:any[]=[]
    constructor(private service: BookService) {
        
    }
    ngOnInit() : any{
        this.service.getAllBooks().subscribe((data:any)=>{this.booksAll=data})
    }
}
