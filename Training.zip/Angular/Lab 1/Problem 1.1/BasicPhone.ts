export class BasicPhone{
   public mobileType:string="BasicPhone"
}