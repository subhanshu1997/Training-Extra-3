export class SmartPhone{
    mobileType:string="SmartPhone"
}