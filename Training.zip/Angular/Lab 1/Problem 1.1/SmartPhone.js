"use strict";
exports.__esModule = true;
var SmartPhone = /** @class */ (function () {
    function SmartPhone() {
        this.mobileType = "SmartPhone";
    }
    return SmartPhone;
}());
exports.SmartPhone = SmartPhone;
