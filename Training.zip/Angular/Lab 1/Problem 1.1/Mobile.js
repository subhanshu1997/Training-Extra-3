"use strict";
exports.__esModule = true;
var BasicPhone_1 = require("./BasicPhone");
var SmartPhone_1 = require("./SmartPhone");
var Mobile = /** @class */ (function () {
    function Mobile() {
        this.basicPhone = new BasicPhone_1.BasicPhone();
        this.smartPhone = new SmartPhone_1.SmartPhone();
        this.arr = [
            { mobileId: 101, mobileName: "Nokia", mobileCost: 5000, mobileType: this.basicPhone.mobileType },
            { mobileId: 101, mobileName: "Samsung", mobileCost: 10000, mobileType: this.smartPhone.mobileType },
            { mobileId: 101, mobileName: "Huawei", mobileCost: 90000, mobileType: this.basicPhone.mobileType },
            { mobileId: 101, mobileName: "Xiaomi", mobileCost: 80000, mobileType: this.smartPhone.mobileType }
        ];
    }
    Mobile.prototype.printMobileDetails = function () {
        for (var _i = 0, _a = this.arr; _i < _a.length; _i++) {
            var data = _a[_i];
            console.log(data);
        }
    };
    return Mobile;
}());
exports.Mobile = Mobile;
new Mobile().printMobileDetails();
