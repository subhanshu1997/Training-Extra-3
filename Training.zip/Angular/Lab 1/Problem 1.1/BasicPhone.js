"use strict";
exports.__esModule = true;
var BasicPhone = /** @class */ (function () {
    function BasicPhone() {
        this.mobileType = "BasicPhone";
    }
    return BasicPhone;
}());
exports.BasicPhone = BasicPhone;
