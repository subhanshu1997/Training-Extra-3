import { BasicPhone } from "./BasicPhone";
import { SmartPhone } from "./SmartPhone";

export class Mobile{
    mobileId:number
    mobileName:number
    mobileCost:number
    basicPhone:any=new BasicPhone()
    smartPhone:any=new SmartPhone()
    arr:any[]=[
        {mobileId:101,mobileName:"Nokia",mobileCost:5000,mobileType:this.basicPhone.mobileType},
        {mobileId:101,mobileName:"Samsung",mobileCost:10000,mobileType:this.smartPhone.mobileType},
        {mobileId:101,mobileName:"Huawei",mobileCost:90000,mobileType:this.basicPhone.mobileType},
        {mobileId:101,mobileName:"Xiaomi",mobileCost:80000,mobileType:this.smartPhone.mobileType}
    ]
    printMobileDetails(){
        for(let data of this.arr){
            console.log(data)
        }
    }
}
new Mobile().printMobileDetails()