import { Component } from "@angular/core";
@Component({
    selector:'add-Employee',
    templateUrl:'app.addEmployee.html'

})
export class AddEmployee{
    arr:any[]=[
        {empId:101,empName:"Subhanshu",empSalary:50000,empDepartment:"Java"}
    ]
    empId:number
    empName:string
    empSalary:number
    empDepartment:string
    AddEmployee(){
        this.arr.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment})
        alert(this.empId+" "+this.empName+" "+this.empSalary+" "+this.empDepartment)
    }
}