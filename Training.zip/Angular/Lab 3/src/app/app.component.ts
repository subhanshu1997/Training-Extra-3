﻿import { Component} from '@angular/core';
import { listLazyRoutes } from '@angular/compiler/src/aot/lazy_routes';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html',
    styleUrls:['app.component.css']
})
export class AppComponent{
    productId:number
    productName:string
    productCost:number
    status:boolean=false
    productCategory:string
    online:string
    radio:string="YES"
    list:any[]=[]
    addProduct(){
       this.status=true
        }
        setRadio(radio:string){
            this.radio=radio
        }
        addList(item:any){
            if(this.list.indexOf(item)>-1){
                let index=this.list.indexOf(item)
                this.list.splice(index,1)
            }
            else{
                this.list.push(item)
            }
            this.status=false     
        }
    }