import { Component } from "@angular/core";

@Component({
    selector:'add-emp',
    templateUrl:'app.add.html',
    styleUrls:['app.add.css']

})
export class AddEmployeeComponent{
    arr:any[]=[
        {empId:1001,empName:"ABCD",empSalary:5000,empDepartment:"Java"},
        {empId:1004,empName:"Subhanshu",empSalary:50000,empDepartment:"Java"},
        {empId:1005,empName:"ABCD",empSalary:100000,empDepartment:"Java"}
    ]
    empId:number
    empName:string
    empSalary:number
    empDepartment:string
    empId1:number
    empName1:string
    empSalary1:number
    empDepartment1:string
    id:number
    addEmployee():any{
        // alert("employee added"+this.empId+" "+this.empName+" "+this.empSalary+" ")
        // this.arr.push(this.empId+this.empName+this.empSalary)
        this.arr.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment})
        console.log(this.arr)
    }
    deleteEmployee(i:number):any{
        this.arr.splice(i,1)
    }
    updateEmployeeFiller(i:number){
        this.empId1=this.arr[i].empId
        this.empName1=this.arr[i].empName
        this.empSalary1=this.arr[i].empSalary
        this.empDepartment1=this.arr[i].empDepartment
        this.id=this.arr[i].empId
    }
    updateEmployee(){
        let index=0
        for(let data of this.arr){
            if(data.empId==this.id){
                index=this.arr.indexOf(data)
            }
        }
        this.arr[index].empId=this.empId1
        this.arr[index].empName=this.empName1
        this.arr[index].empSalary=this.empSalary1
        this.arr[index].empDepartment=this.empDepartment1
    }
    
}